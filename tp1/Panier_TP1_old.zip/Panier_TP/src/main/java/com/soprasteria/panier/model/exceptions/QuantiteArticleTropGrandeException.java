package com.soprasteria.panier.model.exceptions;

public class QuantiteArticleTropGrandeException extends Exception {
	public QuantiteArticleTropGrandeException( String message ) {
		super( message );
	}
}
