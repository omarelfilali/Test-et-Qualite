package com.soprasteria.panier.model.exceptions;

public class VersionDeFichierNonGeree extends Exception {
	public VersionDeFichierNonGeree( String message ) {
		super( message );
	}
}
