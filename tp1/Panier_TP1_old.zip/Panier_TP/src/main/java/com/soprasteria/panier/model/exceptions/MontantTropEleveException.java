package com.soprasteria.panier.model.exceptions;

public class MontantTropEleveException extends Exception {
	public MontantTropEleveException( String message ) {
		super( message );
	}
}
