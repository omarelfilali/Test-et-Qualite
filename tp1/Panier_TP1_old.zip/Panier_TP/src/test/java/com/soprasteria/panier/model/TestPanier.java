package com.soprasteria.panier.model;

import static org.junit.Assert.*;

import org.junit.*;

import com.soprasteria.panier.model.Article;
import com.soprasteria.panier.model.Panier;
import com.soprasteria.panier.model.exceptions.ArticleInexistantException;
import com.soprasteria.panier.model.exceptions.MontantTropEleveException;
import com.soprasteria.panier.model.exceptions.QuantiteArticleTropGrandeException;
import com.soprasteria.panier.model.exceptions.TropDeReferencesException;
import com.soprasteria.tools.OutilsChaine;

import java.util.ArrayList;
import java.util.Date;

/**
 * Classe de tests unitaires de la classe Panier
 * <P>
 * Teste les fonctions de base non triviales de la classe Panier - Ajout
 * d'articles - Retrait d'un article - Changement de quantit� d'un article -
 * Vidage d'un panier - Impression du ticket - Gestion de la remise
 * <P>
 * Couvre les exigences : EXG_PAN_01, EXG_PAN_02, EXG_PAN_03
 * 
 * @author Olivier
 * @version 2.1
 */
public class TestPanier {
	/**
	 * Les donnees de test
	 */
	static Panier pan;
	static Article art1, art2, art3;
	static ArrayList<Article> liste;

	/**
	 * Initialisation des donnees de test avant l'ensemble des tests
	 */
	@BeforeClass
	public static void initTests() {
		pan = new Panier( );
		art1 = new Article( 100.00 , "REF001" , "LIBELLE01" , 9.99 );
		art2 = new Article( 100.00 , "REF002" , "LIBELLE02" , 10.00 );
		liste = new ArrayList<Article>( );
		for (int i = 0; i < 100000; i++)
			liste.add( new Article( 100.00 , "REF00" + i , "LIB" + i , 10.00 ) );
	}

	/**
	 * Remise a zero du panier avant chaque test
	 */
	@Before
	public void avantTest() {
		pan.vider( );
	}

	/**
	 * Test unitaire couvrant l'exigence EXG_PAN_01
	 */
	@Test
	public void testAjouterArticle() throws TropDeReferencesException,
	      QuantiteArticleTropGrandeException, MontantTropEleveException {
	}

	/**
	 * Test unitaire couvrant l'exigence EXG_PAN_04
	 * @throws TropDeReferencesException 
	 */
	@Test(expected = TropDeReferencesException.class)
	public void testAjouterArticleEnTrop() throws TropDeReferencesException {
		throw new TropDeReferencesException("test");
	}
}
