package com.soprasteria.paiement.exception;

public class PaiementException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public PaiementException(String message) {
		super(message);
	}

}
